#!/bin/bash

> ../my_db.txt

cd ../local_database/metadata/ && rm metadata_*
