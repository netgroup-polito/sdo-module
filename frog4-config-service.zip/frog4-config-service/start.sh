#!/bin/bash

sudo python3 start_gunicorn.py
